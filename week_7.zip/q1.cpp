#include <iostream>
#include <windows.h>
#include <vector>

using namespace std;

//Base class
class Note{
protected:

    int frequency;
    int duration;

public:

    //Default constructor
    Note() : frequency(440), duration(500) {}

    Note(int freq, int dur) : frequency(freq), duration(dur) {}

    //Function to use Beep
    void playNote(){
        Beep(frequency, duration);
    }
};

//Derived classes (not in alphabetical order)
class D : public Note{
public:

    //Default constructor
    D() : Note(590, 500) {}
    // Copy constructor
    D(const D &source) : Note(source) {}
    //Constructor that gets parameters
    D(int freq, int dur) : Note(freq, dur) {}
    //Destructor
    ~D() {}
};

class G : public Note{
public:

    G() : Note(780, 500){}

    G(const G &source) : Note(source) {}

    G(int freq, int dur) : Note(freq, dur) {}

    ~G() {}
};

class A : public Note{
public:

    A() : Note(880, 500) {}

    A(const A &source) : Note(source) {}

    A(int freq, int dur) : Note(freq, dur) {}

    ~A() {}
};

class B : public Note{
public:

    B() : Note(990, 500) {}

    B(const B &source) : Note(source) {}

    B(int freq, int dur) : Note(freq, dur) {}

    ~B() {}
};

class E : public Note{
public:

    E() : Note(660, 500) {}

    E(const E &source) : Note(source) {}

    E(int freq, int dur) : Note(freq, dur) {}

    ~E() {}
};

class C : public Note{
public:

    C() : Note(520, 500) {}

    C(const C &source) : Note(source) {}

    C(int freq, int dur) : Note(freq, dur) {}

    ~C() {}
};

int main(){

    //A vector that stores pointers to Note class and initialzing is in musical order
    vector<Note*> Music = {new D(), new G(), new A(), new B(), new A(), new G(), new A(), new G(), new B(), new D(), new E(), new G(), new A(), new B(), new A(), new G(), new A(), new G(), new B(), new D(), new C(), new B(), new A(), new G(),new A(), new B(), new A(), new G()};

    //Loop for playing all notes
    for (Note* note : Music) {
        note->playNote();
        cout << endl;
        Sleep(30);
    }

    //Deleting created classes
	for (Note* note : Music) {
	        delete note;
	    }

    return 0;
}
