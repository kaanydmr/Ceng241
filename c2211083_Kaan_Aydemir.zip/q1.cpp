#include <iostream>
#include <windows.h>
#include <vector>

using namespace std;

//Base class
class Note {
protected:
    int frequency;
    int duration;

public:
    // Default constructor
    Note() : frequency(440), duration(500) {}

    // Parameterized constructor
    Note(int freq, int dur) : frequency(freq), duration(dur) {}

    // Getter for frequency
    int getFrequency() const {
        return frequency;
    }
	
	//To print all notes name(Overriden)
	virtual string getNoteName() const {
        return "Note";
    }
	
	int getDuration() const {
		
		return duration;
	}
    // Overload "+ operator
    Note operator+(int val) {
        Note result(*this);
        result.frequency += val;
        return result;
    }

    // Overload "-" operator
    Note operator-(int val){
        Note result(*this);
        result.frequency -= val;
        return result;
    }
	
	void setfreq(int freq){
		
		frequency = freq;
	}
    
    // Function to use Beep
    void playNote() {
        Beep(frequency, duration);
    }
};

//Overload << operator for printing Note information
ostream& operator<<(ostream& oper, const Note* note) {
    oper << note->getNoteName() << ": Frequency: " << note->getFrequency() << " Duration: " << note->getDuration();
    return oper;
}

// Derived classes (not in alphabetical order)
class D : public Note {
public:
    // Default constructor
    D() : Note(590, 600) {}
    // Copy constructor
    D(D& source) : Note(source) {}
    // Constructor that gets parameters
    D(int freq, int dur) : Note(freq, dur) {}
    // Destructor
    ~D() {}
    
    //Overloaded "=" operator 
    D& operator=(const D& other) {
        if (this != &other) {
            frequency = other.frequency;
            
        }
        return *this;
    }
    //Overloaded "+" operator 
    D operator+(int val) {
        D result(*this);
        result.frequency += val;
        return result;
    }

    //Overloaded "-" operator
    D operator-(int val){
        D result(*this);
        result.frequency -= val;
        return result;
    }
    
    //Overrited to print class name
    virtual string getNoteName() const override {
        return "D";
    }
    
};

class G : public Note {
public:
    G() : Note(780, 500) {}
    G(const G& source) : Note(source) {}
    G(int freq, int dur) : Note(freq, dur) {}
    ~G() {}
    
    G& operator=(const G& other) {
        if (this != &other) {
            frequency = other.frequency;

        }
        return *this;
    }
    G operator+(int val) {
        G result(*this);
        result.frequency += val;
        return result;
    }


    G operator-(int val){
        G result(*this);
        result.frequency -= val;
        return result;
    }

    
    virtual string getNoteName() const override {
        return "G";
    }
};

class A : public Note {
public:
    A() : Note(880, 480) {}
    A(const A& source) : Note(source) {}
    A(int freq, int dur) : Note(freq, dur) {}
    ~A() {}
    
    A& operator=(const A& other) {
        if (this != &other) {
            frequency = other.frequency;
        }
        return *this;
    }
    
    
    A& operator+(int val) {
        this->frequency += val;
        return *this;
    }


    A operator-(int val){
        A result(*this);
        result.frequency -= val;
        return result;
    }
    virtual string getNoteName() const override {
        return "A";
    }
   
};

class B : public Note {
public:
    B() : Note(990, 500) {}
    B(const B& source) : Note(source) {}
    B(int freq, int dur) : Note(freq, dur) {}
    ~B() {}
    
    B& operator=(const B& other) {
        if (this != &other) {
            frequency = other.frequency;
        }
        return *this;
    }
    B operator+(int val) {
        B result(*this);
        result.frequency += val;
        return result;
    }


    B operator-(int val){
        B result(*this);
        result.frequency -= val;
        return result;
    }
   virtual string getNoteName() const override {
        return "B";
    }
};

class E : public Note {
public:
    E() : Note(660, 510) {}
    E(const E& source) : Note(source) {}
    E(int freq, int dur) : Note(freq, dur) {}
    ~E() {}
    
    E& operator=(const E& other) {
        if (this != &other) {
            frequency = other.frequency;
        }
        return *this;
    }
    E operator+(int val) {
        E result(*this);
        result.frequency += val;
        return result;
    }


    E operator-(int val){
        E result(*this);
        result.frequency -= val;
        return result;
    }
    
    virtual string getNoteName() const override {
        return "E";
    }
};

class C : public Note {
public:
    C() : Note(520, 500) {}
    C(const C& source) : Note(source) {}
    C(int freq, int dur) : Note(freq, dur) {}
    ~C() {}
    
    C& operator=(const C& other) {
        if (this != &other) {
            frequency = other.frequency;
        }
        return *this;
    }

    C operator+(int val) {
        C result(*this);
        result.frequency += val;
        return result;
    }


    C operator-(int val){
        C result(*this);
        result.frequency -= val;
        return result;
    }
    virtual string getNoteName() const override {
        return "C";
    }
};

class Song {
public:
    A objA;
    B objB;
    C objC;
    E objE;
    G objG;
    D objD;
    
    void changeValues(){
	
		objA = objA - 21;
		
		objD = objD - 22;
		
		objB = objB - 144;
		
		objC = objC + 25;
		
		objE = objE - 50;
		
		objG = objG - 100;	
		
	}

    vector<Note*> Music = {&objD, &objG, &objA, &objB, &objG, &objG, &objB, &objD, &objE, &objG, &objB, &objG, &objG, &objB, &objD, &objC, &objB, &objG, &objB, &objG, &objA, &objG};
	
	
	//Prints note information
    void printSong() {
        for (Note* note : Music) {
            cout << note << endl;         
            
        }
    }

    //Plays song
    void playSong() {
        for (Note* note : Music) {
        	
            note->playNote();
            Sleep(30);
        }
    }
};

int main() {
	
    Song Music;  

	Music.changeValues();
    Music.printSong();
    Music.playSong();
    return 0;
}
