#include <string>
#include <iostream>

using namespace std;

#define PI 3.14

//Function prototypes
double calculateArea(int sideLength);
double calculateArea(int length, int width);
double calculateArea(double radius);
double calculateArea(double base, double height);


int main(){
    
    string typ{};
    
    double area{}; 
    
    cout << "Enter Area Type or their corresponding numbers(1 - Square, 2 - Rectangle, 3 - Circle, 4 - Triangle): " ;
    cin >> typ;
    
    if(typ == "Circle" || typ == "circle" || typ == "3"){
        
        double rad{};
        
        cout << "Enter radious: ";
        cin >> rad;
        
        area = calculateArea(rad);
        
        cout << "Area is: " << area;
        
    }
    
    else if(typ == "square" || typ == "Square" || typ == "1"){
        
        int side{0};
        
        cout << "Enter side length: ";
        cin >> side;
        
        area = calculateArea(side);
        
        cout << "Area is: " << area << endl;
        
    }
    
    else if(typ == "rectangle" || typ == "Rectangle" || typ == "2"){
        
        int length{0}, width{0};
        
        cout << "Enter length: ";
        cin >> length;
        cout << "Enter width: ";
        cin >> width;
        
        area = calculateArea(length, width);
        
        cout << "Area is: " << area << endl;
        
    }
    
    else if(typ == "triangle" || typ == "Triangle" || typ == "4"){
        
        double base{0}, height{0};
        
        cout << "Enter base length: ";
        cin >> base;
        cout << "Enter heigth length: ";
        cin >> height;
        
        area = calculateArea(base, height);
        
        cout << "Area is: " << area << endl;
        
    }
    
    else{
        cout << "Enter valid shape or number";
    }
    
    return 0;
}

// Function to calculate the area of a square
double calculateArea(int sideLength){
    
    double area {0};
    
    area = sideLength * sideLength;
    
    return area;
    
}

// Function to calculate the area of a rectangle
double calculateArea(int length, int width){
    
    double area {0};
    
    area = length * width;
    
    return area; 
}

// Function to calculate the area of a circle
double calculateArea(double radius){
    
    double area {0};
    
    area = PI * (radius * radius);
    
    return area;
    
}

// Function to calculate the area of a triangle
double calculateArea(double base, double height){
    
    double area {0};
    
    area = (base * height) / 2;
    
    return area;
    
}