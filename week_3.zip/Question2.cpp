#include <iostream>
#include <string>

using namespace std;

//For concatenate 2 strings 
string concatenateStrings(string str1, string str2){
	
    return str1 + str2;
}
//For concatenate 3 strings
string concatenateStrings(string str1, string str2, string str3){
	
    return str1 + str2 + str3;
}

//For reversing string
string reverseString(string str){
	
    int len = str.length();
    int n = len-1;
    int i = 0;
    while(i<=n){
    	
        swap(str[i],str[n]);
        n = n-1;
        i = i+1;
    }
    return str;
}

//For counting vowels in string
int countVowels(string str){
	
    int count = 0, place = 0;
    
    while(place < str.length()){
        
        if (str[place] == 'a' || str[place] == 'e' || str[place] == 'i' || str[place] == 'o' || str[place] == 'u' || str[place] == 'A' || str[place] == 'E' || str[place] == 'I' || str[place] == 'O' || str[place] == 'U' ) {
        	
            count++;
        }
        
        place++;
    }
    
    return count;
}

int main(){
	
    int menu;
    
    //Asking user preferance
    cout << "1- Concatenate two strings" << endl;
    cout << "2- Concatenate three strings" << endl;
    cout << "3- Reverse string" << endl;
    cout << "4- Count vowels in string" << endl;
    cout << "Choose an oparation (1-4): ";
    cin >> menu;

    if(menu == 1){
    	
        string str1, str2, cong;
        
        cout << "Enter first string: ";
        cin >> str1;
        
        cout << "Enter second string: ";
        cin >> str2;
        
        cong = concatenateStrings(str1, str2);
        
        cout << "Concatenated string: " << cong << endl;
        
    }
    
	else if(menu == 2){
		
        string str1, str2, str3, cong;
        
        cout << "Enter first string: ";
        cin >> str1;
        
        cout << "Enter second string: ";
        cin >> str2;
        
        cout << "Enter third string: ";
        cin >> str3;
        
        cong = concatenateStrings(str1, str2, str3);
        
        cout << "Concatenated string: " << cong << endl;
        
    } 
    
	else if(menu == 3){
		
        string str, reverse;
        
        cout << "Enter a string: ";
        cin >> str;
        
        reverse = reverseString(str);
        
        cout << "Reversed string: " << reverse << endl;
        
    } 
    
	else if(menu == 4){
		
        string str;
        
        cout << "Enter a string: ";
        cin >> str;
        
        cout << "Number of vowels in the string: " << countVowels(str) << endl;
        
    } 
    
	else{
		
        cout << "Choose a valid option (1-4)." << endl;
    }

    return 0;
}
