#include <iostream>
#include <windows.h>
#include <vector>

using namespace std;

class Note{
private:
	
    int frequency;
    int duration;

public:
	
    Note() : frequency(440), duration(500) {}

    Note(int freq, int dur) : frequency(freq), duration(dur) {}

    int getFrequency(){
        return frequency;
    }

    int getDuration(){
        return duration;
    }
    
    void visual(){
    	
    	for(int a = 0 ; a < (frequency / 40) ; a++)
    		cout << "=-=" ;
    	
	}
    
    void playNote(){
        Beep(frequency, duration);
    }
};


class D : public Note{
public:
	
    D() : Note(590, 500) {} 

    D(const D &source) : Note(source) {}

    D(int freq, int dur) : Note(freq, dur) {}

    ~D() {}
};

class G : public Note{
public:
	
    G() : Note(780, 500) {} 

    G(const G &source) : Note(source) {}

    G(int freq, int dur) : Note(freq, dur) {}

    ~G() {}
};

class A : public Note{
public:
	
    A() : Note(880, 500) {} 

    A(const A &source) : Note(source) {}

    A(int freq, int dur) : Note(freq, dur) {}

    ~A() {}
};

class B : public Note{
public:
	
    B() : Note(990, 500) {} 

    B(const B &source) : Note(source) {}

    B(int freq, int dur) : Note(freq, dur) {}

    ~B() {}
};

class E : public Note{
public:
	
    E() : Note(660, 500) {} 

    E(const E &source) : Note(source) {}

    E(int freq, int dur) : Note(freq, dur) {}

    ~E() {}
};

class C : public Note{
public:
	
    C() : Note(520, 500) {} 

    C(const C &source) : Note(source) {}

    C(int freq, int dur) : Note(freq, dur) {}

    ~C() {}
};

int main(){
	
    vector<Note> Music = {D(), G(), A(), B(), A(), G(), A(), G(), B(), D(), E(), G(), A(), B(), A(), G(), A(), G(), B(), D(), C(), B(), A(), G(), A(), B(), A(), G() };

    for (Note note: Music){
    	
        note.playNote();
        
        note.visual();
        cout << endl;
        
        Sleep(30); 
    }

    return 0;
}
